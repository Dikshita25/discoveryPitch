GC Academic Excellence Contest 2026 - Web page package
========================================================

Contents
--------
index.html          The complete AEC 2026 page (single page, responsive)
css/style.css       All page styling (GC brand colors, Poppins font)
images/trophy.svg   Hero trophy illustration
images/gc-logo.png  Official GC logo (green)
images/gc-logo-white.png  GC logo (white, for dark footer)
images/favicon.svg  Browser tab icon

How to host
-----------
1. Upload the whole folder (keeping the css/ and images/ structure) to your web server
   or CMS static hosting area.
2. The page loads the Poppins font from Google Fonts (fonts.googleapis.com);
   no other external dependencies.
3. To integrate into the GC CMS, copy the <body> sections into your template and
   include css/style.css.

Notes
-----
- The header GC mark and smile badge are coded in HTML/CSS. To use the official
  logo images instead, replace the .gc-mark element in index.html with
  <img src="images/gc-logo.svg" alt="GC" height="32">.
- Social links point to the official contest Facebook group and Instagram account.
- Placeholder links (href="#") should be pointed at the correct gc.dental pages.
